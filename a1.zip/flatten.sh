#!/bin/bash

zipfile=$1
dir=$2
unzip -j -o $1 -d $2 
